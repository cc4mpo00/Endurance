# Endurance

Juego 3D en el navegador (HTML, CSS y JavaScript con Three.js) basado en la expedición del Endurance (1914–1916).

Elegí entre Frank Hurley (fotógrafo) y Harry "Chippy" McNish (carpintero) y seguí la historia hasta la foto final de la tripulación.

## Jugar
Abrí `index.html` en el navegador (necesita internet para cargar Three.js y las fuentes) o usá GitHub Pages.

## Controles
- W A S D / flechas: moverse · mouse (clic para fijarlo, Esc lo suelta): mirar
- E: interactuar · F o clic: foto · Shift: correr / esquivar
- En el bote: A y D alternadas

## Créditos
Programación: Claude · Historia: Endurance · Farmacio: La foca
